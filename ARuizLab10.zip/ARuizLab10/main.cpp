//Anthony Ruiz
// CPSC 121 2019 spring

//This will run all of the expected functions.
//Compile alongside the header and "LinkedList.o" to see results.

#include "LinkedList.h"
#include <iostream>
using namespace std;

int main()
{
	LinkedList stack;
	stack.display();
	stack.push_back(8);
	stack.push_back(10);
	cout << "Popped " << stack.pop_back() << endl;
	stack.push_back(12);
	stack.display();
	cout << "Dequeued " << stack.dequeue_front() << endl;
	stack.insert_front(100);
	stack.display();
	cout << stack.size() << endl;
}
