//Anthony Ruiz, Ashley Prus
//CPSC 121 Lab 3
//02/14/19
#include<iostream>
#include<string>
#include<iomanip>
using namespace std;
int main()
{
int width, height, shapeOption, paraOption, direction;
string word;



cout << "choose between the shape to display\n";
cout <<"(1)triangle     	(2)rectangle\n";
cin >> shapeOption;
cout << "choose a parameter.\n"<<
   	"(3)word         	(4)width\n";
cin>>paraOption;

//*************************************************************************
//                          	triangl option
//*************************************************************************
//                          	triangl with word
//************************************************************************
if (shapeOption == 1) {
  if (paraOption == 3) {
    int wordLength;

  	cout << "Do you want the triangle to face up(1) or down(2)? \n";
  	cin >> direction;
  	cout << "Enter a word \n";
  	cin >> word;
    cout<< endl;


    if (direction==1){
      wordLength = word.length();

      for (int i=0; i < wordLength; i++)
      {
        cout << word[0];
        wordLength = word.length();
        cout<< endl;
      }
    }






    if (direction==2){
    wordLength = word.length();

    for (int i=0; i < wordLength;)
    {
      cout << word<< endl;
      word.pop_back();

      wordLength = word.length();
    }



}

  }






  //                          	triangl with number
  //************************************************************************
  else if (paraOption == 4){
	cout << "Do you want the triangle to face up or down? \n";
	cout << "(1)up                   	(2)down\n";
	cin >> direction;

	cout << "Enter width.(has to be odd number.) \n";
	cin >> width;
//start of new code
 string star = "*";
 string extraStar= "*";
int starLength;


  if (direction == 1)//right side up
  {
      do
      {

   starLength = star.length();
        cout<< star<< endl;//displays string

      star+=extraStar;//adds an extra star to the next line of stars

    } while(starLength!= width);
//end of new code




	}
	if (direction == 2)//upside down
  {

    for (int i=0; i < width; i++ )
    {
      star += extraStar;//forms the legth of the first layer of stars
    }

starLength = star.length();//re calculates the stars length



    for(int i = 0; i<starLength;)
    {



    cout<< star<< endl;//ends theline and rewrites next layer of stars.



      star.pop_back();//subract a star from the row
      starLength = star.length();//re calculates the stars length


    }









	}





  }
}
//*************************************************************************
//                          	rectangle option
//*************************************************************************
//                          	rectangle with word
//*************************************************************************
if (shapeOption == 2) {
   if (paraOption == 3){
	cout << "Enter height. \n";
	cin >> height;

	cout << "Enter a word \n";
	cin >> word;

	for( int row= 1; row < height;row++ ){
  	cout << word << endl;
	}






  }







  //                          	rectangle with number(star)
  //*************************************************************************

  if (paraOption == 4){
	cout << "Enter height. \n";
	cin >> height;

	cout << "Enter width. \n";
	cin >> width;

	for ( int row=0; row< height; row++)
	{
    	for(int col= 0; col < width; col++){
      	cout<< '*';
    	}
    	cout << '\n';
	}






  }
}




}
