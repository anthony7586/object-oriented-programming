# Lab-2

https://docs.google.com/document/d/10oOlqY-ezWfZSw2K9Rq1FhUifozrikRkX7xggym6PtI/edit?usp=sharing
