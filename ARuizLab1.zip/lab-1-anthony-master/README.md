# Lab-1

https://docs.google.com/document/d/1x0-s7XiIMf16PnWUOFGJNu5AD-BpU-obe8nNSGbllRA/edit?usp=sharing
