// Ashley Prus, Anthony Ruiz
// CPSC 121 Lab 1
// 1/24/2019

#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

int main(){

int cents, nickels, dimes, quarters, pennies;
int leftOver;

cout << "How much money would you like to calculate for?\n";
cin >> cents;

//start quarters
quarters = cents / 25; //declares # of quarters
leftOver = cents % 25; //remainder after quarters
// end quarters

//start dimes
dimes = leftOver / 10; /// declares # of dimes
leftOver = leftOver % 10;//remainder after dimes
//end dimes

//start nickels
nickels = leftOver / 5;//declares # of nickels
leftOver = leftOver % 5;//remainder after nickels
//end nickels

//start pennies
pennies = leftOver;//total pennies left over
//end pennies

cout << "The cents that you will receive back for " << cents << " will be "
<< quarters << " quarters, " << dimes << " dimes,\n " << nickels << " nickels, and "
<< pennies << " pennies.\n";
cout << "Your total number of coins to be given back will be " <<
quarters + dimes + nickels + pennies << ".\n";

return 0;
}
