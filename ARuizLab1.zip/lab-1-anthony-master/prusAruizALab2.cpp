//Ashley Prus & Anthony Ruiz
//<01/31/19>
//CPSC 121 Lab 2
#include<iostream>
#include<iomanip>

using namespace std;

int main()
{
  double labworkper, quizzesper, midtermper, finalper, participationper;
  double total = 100; //denominator
  double labworkFinal, quizzesFinal, midtermFinal, finalFinal, participationFinal, numberGrade;

  char letterGrade;

cout<< "Welcome to the grade calculator!\n";
cout<<"Use -1 to indicate no information\n\n\n";

//retrieving percent grade from student.


  cout << "enter quiz grade: ";
  cin >> quizzesper;//percentage for quizzes
  cout <<'\n';

  cout << "enter lab grade: ";
  cin >> labworkper;//percentage for lab
  cout <<'\n';

  cout << "enter midterm grade: ";
  cin >> midtermper;//percentage for midterm
  cout <<'\n';

  cout << "enter final grade: ";
  cin >> finalper;//percentage for final
  cout <<'\n';

  cout << "enter participation grade: ";
  cin >> participationper;//percentage for participation
  cout <<'\n';

//end of user input

//begggining of total grade calculation


labworkFinal = labworkper * .35;//points towards actual grade
      if (labworkper == -1){
        total = total - 35;
        labworkFinal= 0;
      }


quizzesFinal = quizzesper * .15;//points towards actual grade
      if (quizzesper == -1){
        total = total - 15;
        quizzesFinal = 0;
      }

midtermFinal = midtermper * .15;//points towaaaards actual grade
      if (midtermper == -1){
        total = total - 15;
        midtermFinal = 0;
      }

finalFinal = finalper * .25;//points towards actual grade
      if (finalper == -1){
        total = total - 25;
        finalFinal = 0;
      }

participationFinal = participationper * .10;//points towards actual grade
      if (participationper == -1){
        total = total - 10;
        participationFinal = 0;
      }








//final outcome
numberGrade = finalFinal + participationFinal + midtermFinal + quizzesFinal
 + labworkFinal;

 numberGrade = numberGrade / total * 100;


//determining the letter   grade from the numeral grade.
 if (numberGrade < 60){
   letterGrade = 'F';
 }
  if (numberGrade < 70 && numberGrade >= 60){
   letterGrade = 'D';
 }
  if (numberGrade < 80 && numberGrade >= 70){
   letterGrade = 'C';
 }
  if (numberGrade < 90 && numberGrade >= 80){
   letterGrade = 'B';
 }
  if (numberGrade <= 100 && numberGrade >= 90){
   letterGrade = 'A';
 }
//end of determining the letter grade.



//last line of output. letter graddde and number grade
 cout<< "Final Class Grade: " << letterGrade <<"  "<< fixed  << setprecision(2)
  << numberGrade<< '%'<< endl;





return 0;
}
//end of program
