int binarySearch(int array[], int first, int last, int value)
{
	int middle;

	if (first > last)
		return -1;
	middle = (first + last) / 2;
	if (array[middle] == value)
		return middle;
	if (array[middle] < value)//search right
		return binarySearch(array,middle+1,last,value);
	else//search left
		return binarySearch(array,first,middle-1,value);
}

void sortArray(int array[], int size)
{
	bool swapped = true;
	while(swapped)
	{
		swapped = false;
		for(int i = 0; i < size-1; i++)
		{
			if(array[i] > array[i+1])
			{
				int temp = array[i+1];
				array[i+1] = array[i];
				array[i] = temp;
				swapped = true;
			}
		}
	}
}