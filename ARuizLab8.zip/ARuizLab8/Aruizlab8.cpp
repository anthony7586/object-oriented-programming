// Anthony Ruiz
// Comp Sci 121
// Lab 8
// 4/16/19

#include "Separated.h"
#include <iostream>
using namespace std;

void myMain()
{

int size;//size of the array
//future array to be allocated
int *arrayPtr= nullptr;
int runAgain = 0;
int numSearch;

	//Treat this file as your main; all of your work should be done here
	cout << "MyMain has been called\n";

	cout<< "how large would you like to make the array?\n";
	cin >> size;

arrayPtr = new int[size];





//making the array
for (int i=0; i < size; i++){
  arrayPtr[i] = rand() % 100;
	cout << arrayPtr[i] << endl;
}

cout << "_______________________\n";
cout << "Sorted: \n";

sortArray(arrayPtr,size);//sorting


//displaying
for (int i=0; i < size; i++)
{
cout << arrayPtr[i] << endl;
}

cout << "what number would you like to find?\n";
cin >> numSearch;
cout << endl << binarySearch(arrayPtr,0,size-1, numSearch)<< "\n\n\n";






cout << "Would you like to run the code again?\n";
cout << "Enter a 1 for yes\n";
cout << "Enter a 0 for no\n";

cin >> runAgain;






//this is the recursion
if (runAgain == 1){
myMain();
}

if (runAgain == 0){
cout << "l8r sk8r\n";}

}
