//Eric May
//Spring 2019
//CPSC 121

//This file will be the starting point for the program; it will make a call
//to a function that you provide (myMain) in a separate file. 

//If the provided makefile is used, it will automatically find the
//implementation of myMain if it is located in a cpp file in the same folder

//Included for compiler
void myMain();

int main()
{
	myMain();
	return 0;
}
