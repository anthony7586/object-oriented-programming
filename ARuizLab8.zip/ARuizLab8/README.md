# Lab-8

CPSC 121
Lab 8
Fall 2018
Eric May
Pointers, Dynamic Memory Allocation, and Multiple Files
We are going to allow the user to tell us how large of an array to generate, sort it, then search for a value. This will involve multiple files that contain definitions, the first time for us.

Ask the user how large they want their array to be
Dynamically allocate an array with specified size using a pointer
Fill each value in the array with rand() % 100
Display the array
Sort the array using one of the functions found in Separate.h
Display the array again
Generate a number (rand()%100 or user input, your choice) and display the results when your sorted array is searched for that number using the other function in Separate.h
Ask the user if they wish to return to step 1 or exit. Don’t allow for any memory leaks!

Points
2 - Filename and Header
2 - Proper use of data contained in other files
2 - Proper use of functions, RNG
4 - Syntactically correct use of pointers, dynamic allocation, no memory leaks


--------------------------------------------------------
    assignment instructions also found in ;link below 

--------------------------------------------------------


https://drive.google.com/open?id=1whnsmdnQBI67mq0PLlZwlUN4ZlPaoexdTGyvMrDF4oI

---> work is in the "MyMain" function definition.
