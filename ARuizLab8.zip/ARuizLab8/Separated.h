//Recursive Binary Search function
//With an array of size 10, initial values for first and last would be 0 and 9
int binarySearch(int array[], int first, int last, int value);

void sortArray(int array[], int size);