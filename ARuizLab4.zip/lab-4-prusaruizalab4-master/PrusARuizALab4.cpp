//anthony ruiz, ashley prus
//CPSC 121 Lab4
//02/24/19
#include<iostream>
#include<string>

using namespace std;



//prototypes
void printHW();
string printBetween(int, int);
bool primeTest(int);
int leastCommonDenominator(int, int);
void square();
//end of prototypes






  int main()
{



//variables
int menuOption;
int primeNum;
int a=0, b=0;
int int1, int2;



/*    	display menu    	*/
cout << "pick a function\n";
cout << "(1) Hello, world\n";
cout << "(2) Print between\n";
cout << "(3) Is prime or not\n";
cout << "(4) Least common denominator\n";
cout << "(5) Squared opposite\n";

  cin >> menuOption; //take in menu input from the user

	if (menuOption == 1 )//if user picks
	{
  	printHW();
	}

	if (menuOption == 2 )//if user picks print between 
	{
  	cout << "Enter your initial digit\n";
  	cin >> a;
  	cout << "Enter your final digit\n";
  	cin >> b;

  	printBetween(a,b);
	}

	if (menuOption == 3)//if user picks prime number
	{
    	cout << "Enter a positive number \n";
    	cin >> primeNum;

      if(primeTest(primeNum) == 0)
      {
      cout << primeNum << " is a prime number\n";
      }

      else
      {
        cout<< primeNum << " is not a prime number.\n";
      }
	}


  if (menuOption ==4)//if user picks least common denominator
  {
      cout << "enter two postitive intigers seperated by a space\n";
      cin >> int1 >> int2;

      leastCommonDenominator(int1, int2);
  }


  if (menuOption == 5)//if user picks square
  {

    square();
  }














	return 0;
	}
  //end of main().



  /* ********************************************************************
  ***********************************************************************
                          	defenitions
  ***********************************************************************
  *********************************************************************** */






/* ***************************************************************************/
//print Hello world function
void printHW()
{
  cout << "Hello, world!\n";
}
//end of hello world function
/* ***************************************************************************/
//print between function
string printBetween(int a, int b)
{
  string betweenOutput;
  int c;


	if(b < a)
	{
  	c = a;
  	a = b;
  	b = c;
	}

	for(;a <= b; a++)
	{
  	betweenOutput= betweenOutput + to_string(a);

	}

	cout << betweenOutput<< endl;

  return betweenOutput;
}//end of count between function
/* ***************************************************************************/
// prime number function


bool primeTest(int primeNum)
{//this will be the return value (wether it is true or false)

      for(int i =2; i<=primeNum/2; ++i)
      {
          if(primeNum%i == 0)
          {
          return true;
          break;
          }
          else
          {
          return false;
          }
      }}
//end of prime number function
/* ***************************************************************************/
//start of lest common denominator function
int leastCommonDenominator(int a, int b)
{
  int answer;

  answer= a * b;



    if((answer%a == 0)&& (answer%b == 0))
    {

cout << "\nthe loweest common denominator is "<< answer<< endl;
    }

return answer;

}
//end of lowest common multiple function
/* ***************************************************************************/
//start of square
void square()
{


  signed int n;
  cout << "enter a number\n";
  cin >> n;



  signed int y;
  signed int finalResult;
      y = n; // y now holds the n value
      n = n * n; // squared value

    if ((y < 0) && (y != 0))
    {
    finalResult = n * -1;
    }

    if (y>0)
    {
      finalResult = n;
    }


          cout << "Your answer is " << finalResult<< endl;

  }
//end of square function
//end of program
