//anthony ruiz 
//CSPS 121
//04/29/19
#include<iostream>
#include"Gladiator.h"
#include<vector>
#include<string>
#include<random>
#include<iomanip>
using namespace std;



int main()
{

int teamSize;
string newName;



cout << "\n\n\n";
cout << "You will now host a fight between two Gladiator teams.\n";
cout << "How many players would you like the teams to have?\n";
cout << "(Must at least 3)\n";
cin >> teamSize;

while (teamSize < 3)
{
  cout << "\nchoose another number.\n";
  cin >> teamSize;
}

vector<Gladiator> teamBlue;
vector<Gladiator> teamRed;

for (int i= 0; i < teamSize; i++)//this will creat the first three gladiators for team blue
{
cout << "Enter the name for a gladiator for blue team.\n";
cin >> newName;
Gladiator newGladiatorName(newName);
teamBlue.push_back(newGladiatorName);
}
cout << "\n\n\n";
for (int i= 0; i < teamSize; i++)//this will creat the first three gladiators for team red
{
cout << "Enter the name for a gladiator for red team.\n";
cin >> newName;
Gladiator newGladiatorName(newName);
teamRed.push_back(newGladiatorName);
}


cout<< "\n\n";
cout << "Team Blue:\n";
for(int i=0; i< teamSize; i++)//this will display gladiators team blue
{
teamBlue[i].display();
}
cout << "\n\n";
cout << "Team Red:\n";
for(int i=0; i< teamSize; i++)//this will display gladiators team Red
{
teamRed[i].display();
}



//display screen
cout<<"\n\n";
cout<<"   ******  *   *******  *    *  ********   **\n";
cout<<"   *       *   *        *    *     **      **\n";
cout<<"   ******  *   *   ***  ******     **      **\n";
cout<<"   *       *   *     *  *    *     **      **\n";
cout<<"   *       *   *******  *    *     **        \n";
cout<<"                                           **\n\n\n";
//end of display screen
//finght starts
//making a random number engine and distribution





do
{
  int teamRedSize= teamRed.size();
  int teamBlueSize = teamBlue.size();


int i=0;
int dmg;
int randomNum;


randomNum = rand()%teamRedSize;
dmg = teamRed[i].rollDamage();//we will get the damage to be taken by opponent
teamRed[randomNum].takeDamage(dmg);

randomNum = rand()%teamBlueSize;
dmg = teamBlue[i].rollDamage();//we will get the damage to be taken by opponent
teamBlue[randomNum].takeDamage(dmg);






//display stats
cout<< "\n\n";
cout<< "New Stats:\n\n";
cout << "Team Blue:\n";
for(int i=0; i< teamSize; i++)//this will display gladiators team blue
{
teamBlue[i].display();
}
cout << "\n\n";
cout << "Team Red:\n";
for(int i=0; i< teamSize; i++)//this will display gladiators team Red
{
teamRed[i].display();
}



//removing players who died in a loop
for(int k=0;k<teamSize; k++)
{

  int curHealth;
  curHealth = teamBlue[k].getCurHealth();
    if (curHealth <= 0)
    {
   teamBlue[k].display();
   cout << " \nhas been elimainated.";
      teamBlue.push_back(teamBlue[k]);
      teamBlue.pop_back();
    }
}
for(int k=0;k<teamSize; k++)
{
  int curHealth;
  curHealth = teamRed[k].getCurHealth();
    if (curHealth <= 0)
    {
   teamRed[k].display();
   cout << " \nhas been elimainated.";
      teamRed.push_back(teamRed[k]);
    teamRed.pop_back();
    }
}









  i++;
  if(i>=teamSize){
    i=0;
  }//makes sure that the program doesnt go out of the vector scope
}
while ((teamBlue.size()>0) && (teamRed.size() >0));




}
